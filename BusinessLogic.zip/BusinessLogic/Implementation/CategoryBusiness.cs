﻿using BusinessLogic.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CommonModel;
using DataAccessLayer.GenericPattern.Interface;
using DataAccessLayer.DataModel;
using DataAccessLayer.GenericPattern.Implementation;

namespace BusinessLogic.Implementation
{
    public class CategoryBusiness : ICategory
    {
        private readonly IGenericPattern<tbl_Category> _Category;

        public CategoryBusiness()
        {          
            _Category = new GenericPattern<tbl_Category>();
        }
        public List<CategoryModel> CategoryList()
        {
            List<CategoryModel> _categoryList = new List<CategoryModel>();
            var categoryList = _Category.GetAll().ToList();
            categoryList = categoryList ?? new List<tbl_Category>();
            _categoryList = (from cat in categoryList
                             select new CategoryModel
                           {
                               Id=cat.Id,
                               Name=cat.Name,
                               ParentId=Convert.ToInt32(cat.ParentId),
                               Status=Convert.ToBoolean(cat.Status)
                           }).ToList();
            return _categoryList;
        }

        public CategoryModel GetById(int Id)
        {
            CategoryModel _category = new CategoryModel();
            var categoryById = _Category.GetById(Id);

            categoryById = categoryById ?? new tbl_Category();

            _category = new CategoryModel
            {
                Id=categoryById.Id,
                Name=categoryById.Name,
                ParentId=Convert.ToInt32(categoryById.ParentId),
                Status= Convert.ToBoolean(categoryById.Status)
            };
            return _category;
        }

        public CategoryModel GetCategoryList(CategoryModel model)
        {
            throw new NotImplementedException();
        }
        
        public int SaveCategory(CategoryModel model)
        {
            tbl_Category _category = new tbl_Category(model);
            if (model.Id != 0 && model.Id!= null)
            {
                _Category.Upate(_category);

            }
            else
            {
                _category = _Category.Insert(_category);
            }

            return _category.Id;
        }
    }
}
